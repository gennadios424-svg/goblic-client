# Goblic Client

A Fabric (Minecraft 1.21.4) utility client with a click GUI and 25 toggleable modules.

## Using it
Press **Right Shift** in-game to open the Click GUI. Click a button to toggle a module,
hover for a description, press Right Shift again to close. Enabled modules are listed on the HUD.
Quick keys: G Sprint, H Fly, J Fullbright, R KillAura, Z Speed, B GlowESP.
Everything is rebindable under Options > Controls > Goblic Client.

The title screen and pause menu show a large "Goblic Client" banner with the version.

## Modules
**Movement:** Sprint, Fly, Speed, Step, Jesus, Spider, Glide, HighJump, AirJump, AutoJump, FastLadder, AutoWalk, NoFall
**Combat:** KillAura, TriggerBot, Reach, AutoTotem
**Visual:** Fullbright, GlowESP, ItemESP, Zoom
**World / misc / mischief:** Scaffold, Spinbot (others see you spin), Twerk, AntiAFK

## Build
Requires JDK 21.

    gradle wrapper --gradle-version 8.12   # once, if there is no gradlew
    ./gradlew build

The jar is produced in `build/libs/goblic-client-1.0.0.jar`. Drop it in your `mods` folder
with Fabric Loader 0.16.10+ and Fabric API for 1.21.4.

## Adding a module
1. Create a class extending `dev.goblic.module.Module` in `module/modules/`.
2. Override `onTick()`, `onEnable()`, `onDisable()`.
3. Register it in `ModuleManager`, and add a `key.goblic.<name>` line to `en_us.json`.
   It shows up in the Click GUI automatically.

## Note
Cheats are against the rules of most multiplayer servers and can get you banned.
Use it in singleplayer or on servers that allow it.

## Getting the jar
`./gradlew build` (needs internet the first time, to download Minecraft and Fabric).
Or push this folder to a GitHub repo: the included workflow builds it and attaches
`goblic-client-jar` under Actions > latest run > Artifacts. Use the jar that is NOT `-sources`.
