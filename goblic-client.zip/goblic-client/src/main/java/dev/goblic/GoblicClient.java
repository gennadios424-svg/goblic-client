package dev.goblic;

import dev.goblic.gui.ClickGui;
import dev.goblic.gui.GoblicBranding;
import dev.goblic.gui.Theme;
import dev.goblic.module.Module;
import dev.goblic.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Map;

public class GoblicClient implements ClientModInitializer {
    public static final String NAME = "Goblic Client";
    private static ModuleManager modules;

    private final Map<KeyBinding, Module> binds = new LinkedHashMap<>();

    public static ModuleManager getModules() { return modules; }

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        GoblicBranding.register();

        // Right Shift opens the click GUI (rebindable in Controls > "Goblic Client").
        KeyBinding guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.goblic.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, NAME));

        // Optional quick-toggle keys for a few favourites; everything else is toggled from the GUI.
        Map<String, Integer> defaults = Map.of(
                "Sprint", GLFW.GLFW_KEY_G,
                "Fly", GLFW.GLFW_KEY_H,
                "Fullbright", GLFW.GLFW_KEY_J,
                "KillAura", GLFW.GLFW_KEY_R,
                "Speed", GLFW.GLFW_KEY_Z,
                "GlowESP", GLFW.GLFW_KEY_B
        );
        for (Module m : modules.getModules()) {
            int key = defaults.getOrDefault(m.getName(), GLFW.GLFW_KEY_UNKNOWN);
            KeyBinding kb = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.goblic." + m.getName().toLowerCase(), InputUtil.Type.KEYSYM, key, NAME));
            binds.put(kb, m);
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGui());
            }
            for (Map.Entry<KeyBinding, Module> e : binds.entrySet()) {
                while (e.getKey().wasPressed()) e.getValue().toggle();
            }
            if (client.player != null && client.world != null) modules.tick();
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            var tr = mc.textRenderer;
            ctx.drawTextWithShadow(tr, NAME, 4, 4, Theme.GOBLIN_GREEN);
            int y = 16;
            for (Module m : modules.getModules()) {
                if (!m.isEnabled()) continue;
                ctx.fill(2, y - 1, 4, y + 9, Theme.GOLD);
                ctx.drawTextWithShadow(tr, m.getName(), 7, y, Theme.TEXT);
                y += 10;
            }
        });
    }
}
