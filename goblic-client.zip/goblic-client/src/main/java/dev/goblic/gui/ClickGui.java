package dev.goblic.gui;

import dev.goblic.GoblicClient;
import dev.goblic.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGui extends Screen {
    private static final int BTN_W = 104;
    private static final int BTN_H = 14;
    private static final int GAP = 2;
    private static final int PAD = 8;
    private static final int HEADER = 30;

    public ClickGui() {
        super(Text.literal("Goblic Client"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private int cols() {
        return Math.max(1, Math.min(5, (width - 40) / (BTN_W + GAP)));
    }

    private int rows(int count) {
        int c = cols();
        return (count + c - 1) / c;
    }

    private int gridW() { return cols() * (BTN_W + GAP) - GAP; }
    private int gridH(int count) { return rows(count) * (BTN_H + GAP) - GAP; }

    private int originX() { return (width - gridW()) / 2; }

    private int originY(int count) {
        int total = HEADER + gridH(count) + 20;
        return (height - total) / 2 + HEADER;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        List<Module> mods = GoblicClient.getModules().getModules();
        int c = cols();
        int x0 = originX();
        int y0 = originY(mods.size());

        // Panel with gold border
        int px1 = x0 - PAD, py1 = y0 - HEADER - PAD / 2;
        int px2 = x0 + gridW() + PAD, py2 = y0 + gridH(mods.size()) + 22;
        ctx.fill(px1, py1, px2, py2, Theme.MOSS_PANEL);
        ctx.drawBorder(px1, py1, px2 - px1, py2 - py1, Theme.GOLD_DARK);

        // Title
        var matrices = ctx.getMatrices();
        matrices.push();
        matrices.scale(2f, 2f, 1f);
        ctx.drawCenteredTextWithShadow(textRenderer, "Goblic Client", width / 4, (y0 - HEADER + 2) / 2, Theme.GOBLIN_GREEN);
        matrices.pop();
        ctx.drawCenteredTextWithShadow(textRenderer, "Mischief managed.", width / 2, y0 - 12, Theme.GOLD);

        String hoverDesc = null;
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = x0 + (i % c) * (BTN_W + GAP);
            int y = y0 + (i / c) * (BTN_H + GAP);
            boolean hover = mouseX >= x && mouseX < x + BTN_W && mouseY >= y && mouseY < y + BTN_H;

            int bg;
            if (m.isEnabled()) bg = hover ? Theme.GOBLIN_GREEN_HOVER : Theme.GOBLIN_GREEN_DARK;
            else bg = hover ? Theme.MOSS_BUTTON_HOVER : Theme.MOSS_BUTTON;

            ctx.fill(x, y, x + BTN_W, y + BTN_H, bg);
            if (m.isEnabled()) ctx.fill(x, y, x + 2, y + BTN_H, Theme.GOLD);
            ctx.drawCenteredTextWithShadow(textRenderer, m.getName(), x + BTN_W / 2, y + 3,
                    m.isEnabled() ? Theme.TEXT : Theme.TEXT_DIM);
            if (hover) hoverDesc = m.getDescription();
        }

        String footer = hoverDesc != null ? hoverDesc : "Click a module to toggle it. Right Shift closes this menu.";
        int ty = y0 + gridH(mods.size()) + 8;
        ctx.drawCenteredTextWithShadow(textRenderer, footer, width / 2, ty, Theme.TEXT_DIM);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<Module> mods = GoblicClient.getModules().getModules();
        int c = cols();
        int x0 = originX();
        int y0 = originY(mods.size());
        for (int i = 0; i < mods.size(); i++) {
            int x = x0 + (i % c) * (BTN_W + GAP);
            int y = y0 + (i / c) * (BTN_H + GAP);
            if (mouseX >= x && mouseX < x + BTN_W && mouseY >= y && mouseY < y + BTN_H) {
                if (button == 0) mods.get(i).toggle();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
