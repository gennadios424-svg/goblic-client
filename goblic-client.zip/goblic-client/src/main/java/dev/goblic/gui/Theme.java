package dev.goblic.gui;

/** Goblin palette: swamp green, dark moss and gold. All colors are ARGB. */
public final class Theme {
    private Theme() {}

    public static final int GOBLIN_GREEN = 0xFF6CCB2E;
    public static final int GOBLIN_GREEN_DARK = 0xFF3A7D1E;
    public static final int GOBLIN_GREEN_HOVER = 0xFF4FA32A;
    public static final int GOLD = 0xFFE0B020;
    public static final int GOLD_DARK = 0xFF9C7A10;
    public static final int MOSS_PANEL = 0xE0101A0F;
    public static final int MOSS_BUTTON = 0xE01B2A17;
    public static final int MOSS_BUTTON_HOVER = 0xE0293D22;
    public static final int TEXT = 0xFFEFF5E6;
    public static final int TEXT_DIM = 0xFF9DB08A;
}
