package dev.goblic.gui;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;

/** Draws the "Goblic Client" brand on the title screen and the pause menu. */
public final class GoblicBranding {
    private static final int GREEN = Theme.GOBLIN_GREEN;
    private static final int GREY = Theme.GOLD;

    private GoblicBranding() {}

    public static void register() {
        String version = FabricLoader.getInstance().getModContainer("goblic")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("dev");

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            boolean title = screen instanceof TitleScreen;
            boolean pause = screen instanceof GameMenuScreen;
            if (!title && !pause) return;

            ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> {
                var tr = client.textRenderer;

                var matrices = ctx.getMatrices();
                matrices.push();
                matrices.scale(3f, 3f, 1f);
                ctx.drawTextWithShadow(tr, "Goblic Client", 4, 4, GREEN);
                matrices.pop();

                ctx.drawTextWithShadow(tr, "v" + version, 8, 36, GREY);
                ctx.drawTextWithShadow(tr, "Press Right Shift in-game to open the Click GUI", 8, 48, GREY);
            });
        });
    }
}
