package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class Zoom extends Module {
    private int previousFov = 70;

    public Zoom() {
        super("Zoom", "Narrow your field of view to see far away.");
    }

    @Override
    protected void onEnable() {
        previousFov = mc.options.getFov().getValue();
        mc.options.getFov().setValue(30);
    }

    @Override
    protected void onDisable() {
        mc.options.getFov().setValue(previousFov);
    }
}
