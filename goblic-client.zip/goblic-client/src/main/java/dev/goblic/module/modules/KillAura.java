package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private static final double RANGE = 4.2;

    public KillAura() {
        super("KillAura", "Automatically attack the nearest living entity in range.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        LivingEntity best = null;
        double bestDist = RANGE * RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity target)) continue;
            if (target == mc.player || !target.isAlive() || target instanceof ArmorStandEntity) continue;
            double d = mc.player.squaredDistanceTo(target);
            if (d < bestDist) {
                bestDist = d;
                best = target;
            }
        }
        if (best == null) return;

        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
