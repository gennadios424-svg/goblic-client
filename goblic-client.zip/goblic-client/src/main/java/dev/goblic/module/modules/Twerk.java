package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class Twerk extends Module {
    private int ticks;

    public Twerk() {
        super("Twerk", "Rapidly crouch and stand. Pure mischief.");
    }

    @Override
    public void onTick() {
        ticks++;
        mc.options.sneakKey.setPressed(ticks % 4 < 2);
    }

    @Override
    protected void onDisable() {
        mc.options.sneakKey.setPressed(false);
        ticks = 0;
    }
}
