package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;

public class ItemESP extends Module {
    public ItemESP() {
        super("ItemESP", "Outline dropped items through walls.");
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof ItemEntity) e.setGlowing(true);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof ItemEntity) e.setGlowing(false);
        }
    }
}
