package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

public class Step extends Module {
    private static final double STEP_UP = 1.0;

    public Step() {
        super("Step", "Walk up full blocks without jumping.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        EntityAttributeInstance attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(STEP_UP);
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        EntityAttributeInstance attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(0.6);
    }
}
