package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends Module {
    public Scaffold() {
        super("Scaffold", "Place blocks under your feet as you walk.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (!(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return;

        BlockPos target = mc.player.getBlockPos().down();
        if (!mc.world.getBlockState(target).isReplaceable()) return;

        for (Direction dir : Direction.values()) {
            BlockPos neighbor = target.offset(dir);
            if (mc.world.getBlockState(neighbor).isReplaceable()) continue;

            Direction face = dir.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(neighbor).add(Vec3d.of(face.getVector()).multiply(0.5));
            BlockHitResult hit = new BlockHitResult(hitPos, face, neighbor, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);
            return;
        }
    }
}
