package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    public AutoTotem() {
        super("AutoTotem", "Keep a Totem of Undying in your offhand.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < 36; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            // Inventory index -> screen slot: hotbar 0-8 => 36-44, main 9-35 => 9-35.
            int slot = i < 9 ? i + 36 : i;
            // Button 40 swaps the clicked slot with the offhand.
            mc.interactionManager.clickSlot(0, slot, 40, SlotActionType.SWAP, mc.player);
            return;
        }
    }
}
