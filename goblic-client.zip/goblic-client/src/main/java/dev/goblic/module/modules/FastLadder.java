package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class FastLadder extends Module {
    public FastLadder() {
        super("FastLadder", "Climb ladders and vines faster.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.isClimbing() && mc.player.horizontalCollision && !mc.player.isSneaking()) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.25, v.z);
        }
    }
}
