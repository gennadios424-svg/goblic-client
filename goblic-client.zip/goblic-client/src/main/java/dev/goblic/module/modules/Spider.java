package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class Spider extends Module {
    public Spider() {
        super("Spider", "Climb walls by pushing into them.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.horizontalCollision && !mc.player.isSneaking()) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.2, v.z);
        }
    }
}
