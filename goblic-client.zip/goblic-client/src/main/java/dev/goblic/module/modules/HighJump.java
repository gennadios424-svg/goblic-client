package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    public HighJump() {
        super("HighJump", "Jump much higher.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.isOnGround() && mc.options.jumpKey.isPressed()) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.8, v.z);
        }
    }
}
