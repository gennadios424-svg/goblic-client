package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Always sprint while moving forward.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.forwardSpeed > 0 && !mc.player.horizontalCollision && !mc.player.isSneaking()) {
            mc.player.setSprinting(true);
        }
    }
}
