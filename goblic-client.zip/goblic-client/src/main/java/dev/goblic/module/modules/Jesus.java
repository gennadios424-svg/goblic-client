package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class Jesus extends Module {
    public Jesus() {
        super("Jesus", "Float on top of water.");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.player.isSneaking()) return;
        if (mc.player.isTouchingWater()) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.12, v.z);
        }
    }
}
