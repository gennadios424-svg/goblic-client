package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private static final double MULTIPLIER = 1.6;
    private static final double MAX_HORIZONTAL = 0.55;

    public Speed() {
        super("Speed", "Move faster on the ground.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (!mc.player.isOnGround() || mc.player.isSneaking() || mc.player.isTouchingWater()) return;
        if (mc.player.forwardSpeed == 0 && mc.player.sidewaysSpeed == 0) return;

        Vec3d v = mc.player.getVelocity();
        double hx = v.x * MULTIPLIER;
        double hz = v.z * MULTIPLIER;
        double len = Math.sqrt(hx * hx + hz * hz);
        if (len > MAX_HORIZONTAL) {
            hx = hx / len * MAX_HORIZONTAL;
            hz = hz / len * MAX_HORIZONTAL;
        }
        mc.player.setVelocity(hx, v.y, hz);
    }
}
