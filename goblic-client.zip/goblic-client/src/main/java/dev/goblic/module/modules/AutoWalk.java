package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class AutoWalk extends Module {
    public AutoWalk() {
        super("AutoWalk", "Hold forward for you.");
    }

    @Override
    public void onTick() {
        mc.options.forwardKey.setPressed(true);
    }

    @Override
    protected void onDisable() {
        mc.options.forwardKey.setPressed(false);
    }
}
