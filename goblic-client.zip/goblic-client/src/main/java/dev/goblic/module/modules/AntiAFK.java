package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.Hand;

public class AntiAFK extends Module {
    private int ticks;

    public AntiAFK() {
        super("AntiAFK", "Jump and swing now and then so you don't get kicked for idling.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        ticks++;
        if (ticks % 200 == 0 && mc.player.isOnGround()) mc.player.jump();
        if (ticks % 300 == 0) mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Override
    protected void onDisable() {
        ticks = 0;
    }
}
