package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class AutoJump extends Module {
    public AutoJump() {
        super("AutoJump", "Jump automatically while moving.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean moving = mc.player.forwardSpeed != 0 || mc.player.sidewaysSpeed != 0;
        if (moving && mc.player.isOnGround() && !mc.player.isSneaking()) mc.player.jump();
    }
}
