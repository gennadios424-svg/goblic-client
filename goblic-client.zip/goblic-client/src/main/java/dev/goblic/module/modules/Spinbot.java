package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class Spinbot extends Module {
    private float yaw;

    public Spinbot() {
        super("Spinbot", "Spin around for everyone else. Your own view stays put.");
    }

    @Override
    protected void onEnable() {
        yaw = mc.player != null ? mc.player.getYaw() : 0f;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        yaw += 40f;
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, mc.player.getPitch(), mc.player.isOnGround(), mc.player.horizontalCollision));
    }
}
