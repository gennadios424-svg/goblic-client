package dev.goblic.module;

import dev.goblic.module.modules.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new Step());
        modules.add(new Jesus());
        modules.add(new Spider());
        modules.add(new Glide());
        modules.add(new HighJump());
        modules.add(new AirJump());
        modules.add(new AutoJump());
        modules.add(new FastLadder());
        modules.add(new AutoWalk());
        modules.add(new NoFall());
        // Combat
        modules.add(new KillAura());
        modules.add(new TriggerBot());
        modules.add(new Reach());
        modules.add(new AutoTotem());
        // Render / visual
        modules.add(new Fullbright());
        modules.add(new GlowESP());
        modules.add(new ItemESP());
        modules.add(new Zoom());
        // World / misc / mischief
        modules.add(new Scaffold());
        modules.add(new Spinbot());
        modules.add(new Twerk());
        modules.add(new AntiAFK());
    }

    public List<Module> getModules() { return Collections.unmodifiableList(modules); }

    public Module get(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }
}
