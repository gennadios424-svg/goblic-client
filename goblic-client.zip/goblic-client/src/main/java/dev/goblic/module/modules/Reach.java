package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

public class Reach extends Module {
    private static final double ENTITY_REACH = 6.0;
    private static final double BLOCK_REACH = 6.0;

    public Reach() {
        super("Reach", "Extend how far you can hit and place.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        set(EntityAttributes.ENTITY_INTERACTION_RANGE, ENTITY_REACH);
        set(EntityAttributes.BLOCK_INTERACTION_RANGE, BLOCK_REACH);
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        set(EntityAttributes.ENTITY_INTERACTION_RANGE, 3.0);
        set(EntityAttributes.BLOCK_INTERACTION_RANGE, 4.5);
    }

    private void set(net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attribute, double value) {
        EntityAttributeInstance inst = mc.player.getAttributeInstance(attribute);
        if (inst != null) inst.setBaseValue(value);
    }
}
