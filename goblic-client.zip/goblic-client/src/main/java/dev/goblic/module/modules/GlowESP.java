package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class GlowESP extends Module {
    public GlowESP() {
        super("GlowESP", "Outline living entities through walls.");
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity && e != mc.player) e.setGlowing(true);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity && e != mc.player) e.setGlowing(false);
        }
    }
}
