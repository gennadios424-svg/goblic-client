package dev.goblic.module.modules;

import dev.goblic.module.Module;
import net.minecraft.util.math.Vec3d;

public class AirJump extends Module {
    private int cooldown;

    public AirJump() {
        super("AirJump", "Jump again while in mid-air.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (cooldown > 0) cooldown--;
        if (!mc.player.isOnGround() && mc.options.jumpKey.isPressed() && cooldown == 0) {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, 0.42, v.z);
            cooldown = 10;
        }
    }
}
