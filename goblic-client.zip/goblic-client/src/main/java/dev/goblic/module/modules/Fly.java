package dev.goblic.module.modules;

import dev.goblic.module.Module;

public class Fly extends Module {
    public Fly() {
        super("Fly", "Creative-style flight.");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().setFlySpeed(0.08f);
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
        mc.player.getAbilities().setFlySpeed(0.05f);
    }
}
